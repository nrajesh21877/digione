package com.loan.loanlib.model

class Coord {
    var lon = 0.0
    var lat = 0.0
}