package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class LoanSubPurpose(
    @SerializedName("LoanPurposeId")
    val loanPurposeId: String,
    @SerializedName("LoanSubPurposeCode")
    val loanSubPurposeCode: String,
    @SerializedName("LoanSubPurposeId")
    val loanSubPurposeId: Int,
    @SerializedName("MasterType")
    val masterType: String
)