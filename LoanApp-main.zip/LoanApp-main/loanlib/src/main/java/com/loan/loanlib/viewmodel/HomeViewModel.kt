package com.loan.loanlib.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.loan.loanlib.helper.DialogUtil
import com.loan.loanlib.interfaces.Resource
import com.loan.loanlib.model.LeadDetails
import com.loan.loanlib.repository.ApiRepository
import kotlinx.coroutines.Dispatchers

class HomeViewModel(private val repository: ApiRepository) : ViewModel() {

    fun fetchMetaData() = liveData(Dispatchers.IO) {
        try {
            print("fetching meta data")
            emit(repository.getNecessaryDetails { maritalStatus, business,
                                                  purpose, subPurpose,
                                                  education, occupation, income ->
                println("marital Status $maritalStatus")
                println("business $business")
                println("income $income")

            })
        } catch (exception: Exception) {
            emit(exception.message ?: "Error Occurred!")
        }
    }

    fun getMasterData() = liveData(Dispatchers.IO) {
        emit(Resource.loading(data = null))
        try {
            val response = repository.getMasterData()
            emit(Resource.success(data = response))
            DialogUtil.stopProgressDisplay()
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error! "))
            DialogUtil.stopProgressDisplay()
        }
    }

    fun submitLead(details: LeadDetails) = liveData(Dispatchers.IO) {
        emit(Resource.loading(data = null))
        try {
            val response = repository.leadSubmit(details)
            emit(Resource.success(data = response))
            DialogUtil.stopProgressDisplay()
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error! "))
            DialogUtil.stopProgressDisplay()
        }
    }

    fun fetchLeads() = liveData(Dispatchers.IO) {
        emit(Resource.loading(data = null))
        try {
            val response = repository.fetchLeads()
            emit(Resource.success(data = response))
            DialogUtil.stopProgressDisplay()
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error! "))
            DialogUtil.stopProgressDisplay()
        }
    }

    fun getLeadDetails(sqid: String) = liveData(Dispatchers.IO) {
        emit(Resource.loading(data = null))
        try {
            val response = repository.getLeadDetails(sqid)
            emit(Resource.success(data = response))
            DialogUtil.stopProgressDisplay()
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error! "))
            DialogUtil.stopProgressDisplay()
        }
    }
}