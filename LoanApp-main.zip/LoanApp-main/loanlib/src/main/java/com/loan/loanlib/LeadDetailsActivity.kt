package com.loan.loanlib

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.TableLayout
import android.widget.TextView
import androidx.lifecycle.ViewModelProviders
import com.loan.loanlib.api.ApiHelper
import com.loan.loanlib.api.RetrofitBuilder
import com.loan.loanlib.helper.DialogUtil
import com.loan.loanlib.helper.TableLayoutHelper
import com.loan.loanlib.model.LeadDetails
import com.loan.loanlib.viewmodel.HomeViewModel
import com.loan.loanlib.viewmodel.HomeViewModelFactory
import java.util.HashMap
import java.util.LinkedHashMap

class LeadDetailsActivity : AppCompatActivity() {
    private lateinit var viewModel: HomeViewModel

    lateinit var mTable: TableLayout
    lateinit var mTable_bu: TableLayout
    lateinit var mTable_lp: TableLayout
    lateinit var businessEmptyView: TextView
    lateinit var personalEmptyView: TextView
    lateinit var loanEmptyView: TextView
    lateinit var personal_info: TextView
    lateinit var business_info: TextView
    lateinit var loan_info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.summary_activity)
        mTable = findViewById(R.id.table_lead_details)
        mTable_bu = findViewById(R.id.table_lead_details_business)
        mTable_lp = findViewById(R.id.table_lead_purpose_loan)
        businessEmptyView = findViewById(R.id.business_not_found)
        personalEmptyView = findViewById(R.id.personal_not_found)
        loanEmptyView = findViewById(R.id.loan_not_found)
        personal_info = findViewById(R.id.personal_info)
        business_info = findViewById(R.id.business_info)
        loan_info = findViewById(R.id.loan_info)
        val sqId = intent.getStringExtra("SQID")
        print("Sq Id $sqId")
        viewModel = ViewModelProviders.of(
            this,
            HomeViewModelFactory(ApiHelper(RetrofitBuilder.apiService))
        )[HomeViewModel::class.java]

        if (sqId != null) {
            DialogUtil.displayProgress(this)
            viewModel.getLeadDetails(sqId).observe(this, {
                run {
                    if (it.data != null) {
                        if (it.data.isEmpty()) {
                            showEmptyView()
                        } else {
                            showLead(it.data[0])
                        }
                    }
                }
            })
        }

    }

    private fun showEmptyView() {
        loanEmptyView.visibility = View.VISIBLE
        personalEmptyView.visibility = View.GONE
        businessEmptyView.visibility = View.GONE
        personal_info.visibility = View.GONE
        business_info.visibility = View.GONE
        loan_info.visibility = View.GONE

    }

    private fun showLead(lead: LeadDetails) {
        loanEmptyView.visibility = View.GONE
        personalEmptyView.visibility = View.GONE
        businessEmptyView.visibility = View.GONE
        personal_info.visibility = View.VISIBLE
        business_info.visibility = View.VISIBLE
        loan_info.visibility = View.VISIBLE
        val info: HashMap<String, String> = LinkedHashMap()
        info["Name"] = lead.leadName
        info["Mobile Number "] = lead.mobilenumber
        info["PAN No"] = lead.panno
        info["Address"] = lead.permanentAddress
        info["Pin code"] = lead.businessAddressPIN
        info["Email"] = lead.email
        info["Whats app no"] = lead.whatsAppNo
        info["Gender"] = lead.gender
        info["Marital status"] = lead.maritalStatus.toString()
        //business

        TableLayoutHelper.buildTable(this, mTable, info)
        val info1: HashMap<String, String> = LinkedHashMap()
        info1["Occupation"] = lead.occupationType.toString()
        info1["GST no"] = lead.gstCin
        info1["Ownership"] = lead.businessOwnerShipType.toString()
        info1["BU Address"] = lead.businessAddress
        info1["No of Years in BU"] = lead.noOfYrInBusiness.toString()
        info1["Income Type"] = lead.incomeType.toString()
        info1["Annual income"] = lead.annualIncome.toString()
        info1["Annual turnover"] = lead.annualTurnover.toString()

        //loan purpose
        TableLayoutHelper.buildTable(this, mTable_bu, info1)

        val info2: HashMap<String, String> = LinkedHashMap()
        info2["Purpose of loan"] = lead.loanPurpose.toString()
        info2["Sub purpose of loan"] = lead.subLoanPurpose.toString()
        info2["Loan amount"] = lead.loanAmountRequired.toString()
        info2["Repayment Tenure"] = lead.repaymentTenure.toString()
        TableLayoutHelper.buildTable(this, mTable_lp, info2)
    }

}