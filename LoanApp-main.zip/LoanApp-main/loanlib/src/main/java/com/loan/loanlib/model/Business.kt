package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class Business(
    @SerializedName("BusinessCode")
    val businessCode: String,
    @SerializedName("BusinessTypeId")
    val businessTypeId: Int,
    @SerializedName("MasterType")
    val masterType: String
)