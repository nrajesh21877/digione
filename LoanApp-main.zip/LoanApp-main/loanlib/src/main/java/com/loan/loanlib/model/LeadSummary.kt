package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class LeadSummary(
    @SerializedName("CreatedById")
    val createdById: String,
    @SerializedName("LeadName")
    val leadName: String,
    @SerializedName("LeadSqId")
    val leadSqId: Int,
    @SerializedName("Mobilenumber")
    val mobilenumber: String
)