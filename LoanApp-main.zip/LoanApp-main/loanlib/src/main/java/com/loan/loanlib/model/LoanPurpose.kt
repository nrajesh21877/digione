package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class LoanPurpose(
    @SerializedName("LoanPurposeCode")
    val loanPurposeCode: String,
    @SerializedName("LoanPurposeId")
    val loanPurposeId: Int,
    @SerializedName("MasterType")
    val masterType: String
)