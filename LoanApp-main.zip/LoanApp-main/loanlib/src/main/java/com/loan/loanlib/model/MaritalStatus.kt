package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class MaritalStatus(
    @SerializedName("MaritalStatusCode")
    val maritalStatusCode: String,
    @SerializedName("MaritalStatusId")
    val maritalStatusId: Int,
    @SerializedName("MasterType")
    val masterType: String
)