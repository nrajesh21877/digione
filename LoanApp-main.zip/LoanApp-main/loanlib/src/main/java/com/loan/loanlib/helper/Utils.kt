package com.loan.loanlib.helper

import android.util.Patterns
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class Utils {

    companion object {
        fun getStringFromDate(time: Date?, dateFormat: String?): String {
            val sdf = SimpleDateFormat(dateFormat, Locale.ENGLISH)
            return sdf.format(time)
        }

        fun isValidEmail(target: String?): Boolean {
            return if (target == null) {
                false
            } else {
                Patterns.EMAIL_ADDRESS.matcher(target)
                    .matches()
            }
        }

        fun getDateFromString(enteredTime: String?, format: String?): Date? {
            val sdf = SimpleDateFormat(format, Locale.ENGLISH)
            try {
                return sdf.parse(enteredTime)
            } catch (e: ParseException) {
                //  e.printStackTrace();
            }
            return null
        }
//        fun getStringFromDate(time: Date?, dateFormat: String?): String? {
//            val sdf = SimpleDateFormat(dateFormat, Locale.ENGLISH)
//            return sdf.format(time)
//        }
    }

}