package com.loan.loanlib.api

import com.loan.loanlib.model.LeadDetails


class ApiHelper(private val apiService: ApiService) {

    suspend fun loanPurpose() = apiService.loanPurpose()

    suspend fun loanSubPurpose() = apiService.loanSubPurpose()

    suspend fun maritalStatus() = apiService.maritalStatus()

    suspend fun education() = apiService.education()

    suspend fun occupation() = apiService.occupation()

    suspend fun business() = apiService.business()

    suspend fun income() = apiService.income()

    suspend fun leadSubmit(lead: LeadDetails) = apiService.leadSubmit(lead)

    suspend fun getLeadSummary() = apiService.getLeadSummary()

    suspend fun getLeadDetails(sqid: String) = apiService.getLeadDetails(sqid)

    suspend fun getMasterData() = apiService.getMasterData()

    suspend fun getLatLng(zip: String, apiKey: String) = apiService.getLatLng(zip, apiKey)
}