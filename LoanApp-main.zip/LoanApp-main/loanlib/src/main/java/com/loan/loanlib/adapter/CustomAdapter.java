package com.loan.loanlib.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.loan.loanlib.R;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class CustomAdapter<T> extends ArrayAdapter<T> {

    private onBindListener listener;
    private List<T> mList;
    private LayoutInflater mInflater;

    public CustomAdapter(Context context, List<T> list, onBindListener<T> listener) {
        super(context, R.layout.widget_spinner_item, R.id.text1, list);
        setDropDownViewResource(R.layout.widget_spinner_item);

        this.listener = listener;
        mInflater = LayoutInflater.from(context);
        mList = list;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public T getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint("InflateParams")
    @NonNull
    @Override
    public View getView(int position, View convertView, @NotNull ViewGroup parent) {
        return createView(position, parent, false);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return createView(position, parent, true);
    }

    private View createView(int position, ViewGroup parent, boolean flag) {

        final View view = mInflater.inflate(R.layout.widget_spinner_item, parent, false);

        TextView text = view.findViewById(R.id.text1);

        text.setText(listener.getValue(getItem(position)));

        if (flag) {
            text.setPadding(15, 30, 15, 30);
            View div = view.findViewById(R.id.divider);
            div.setVisibility(View.VISIBLE);
        }

        return view;
    }

    public interface onBindListener<T> {
        String getValue(T t);
    }
}
