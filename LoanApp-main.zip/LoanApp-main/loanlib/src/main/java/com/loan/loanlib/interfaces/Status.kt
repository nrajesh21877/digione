package com.loan.loanlib.interfaces

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}