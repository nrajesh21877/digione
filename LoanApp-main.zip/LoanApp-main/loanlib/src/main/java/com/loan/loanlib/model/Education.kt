package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class Education(
    @SerializedName("EduId")
    val eduId: Int,
    @SerializedName("EducationCode")
    val educationCode: String,
    @SerializedName("MasterType")
    val masterType: String
)