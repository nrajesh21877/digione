package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class Occupation(
    @SerializedName("MasterType")
    val masterType: String,
    @SerializedName("OccupationCode")
    val occupationCode: String
)