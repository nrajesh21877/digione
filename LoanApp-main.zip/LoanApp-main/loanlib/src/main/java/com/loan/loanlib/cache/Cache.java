package com.loan.loanlib.cache;


import com.loan.loanlib.model.MasterData;

public class Cache {

    private static Cache cache = new Cache();
    private MasterData masterData;

    public static Cache getInstance() {
        return cache;
    }

    public MasterData getMasterData() {
        return masterData;
    }

    public void setMasterData(MasterData masterData) {
        this.masterData = masterData;
    }

    public void resetMasterData() {
        this.masterData = null;
    }
}
