package com.loan.loanlib.repository

import android.util.Log
import com.loan.loanlib.api.ApiHelper
import com.loan.loanlib.model.*
import kotlinx.coroutines.*


class ApiRepository(private val apiHelper: ApiHelper) {

    suspend fun loanPurpose() = apiHelper.loanPurpose()

    suspend fun loanSubPurpose() = apiHelper.loanSubPurpose()

    suspend fun maritalStatus() = apiHelper.maritalStatus()

    suspend fun education() = apiHelper.education()

    suspend fun occupation() = apiHelper.occupation()

    suspend fun business() = apiHelper.business()

    suspend fun income() = apiHelper.income()

    suspend fun leadSubmit(lead: LeadDetails) = apiHelper.leadSubmit(lead)

    suspend fun fetchLeads() = apiHelper.getLeadSummary()

    suspend fun getLeadDetails(sqId: String) = apiHelper.getLeadDetails(sqId)

    suspend fun getMasterData() = apiHelper.getMasterData()
    suspend fun getLatLng(zip: String, apiKey: String) = apiHelper.getLatLng(zip, apiKey)

    suspend fun getNecessaryDetails(
        returnData: (
            maritalStatusList: List<MaritalStatus>, businessList: List<Business>,
            purposeList: List<LoanPurpose>, subPurposeList: List<LoanSubPurpose>,
            educationList: List<Education>, occupationList: List<Occupation>,
            incomeList: List<Income>
        ) -> Unit
    ) {
        try {
            CoroutineScope(Dispatchers.IO).launch {

                val marital = async {
                    maritalStatus()
                }
                val business = async {
                    business()
                }
                val purpose = async {
                    loanPurpose()
                }
                val subPurpose = async {
                    loanSubPurpose()
                }
                val education = async {
                    education()
                }
                val occupation = async {
                    occupation()
                }
                val income = async {
                    income()
                }

                val maritalResponse = marital.await()
                val businessResponse = business.await()
                val purposeResponse = purpose.await()
                val subPurposeResponse = subPurpose.await()
                val educationResponse = education.await()
                val occupationResponse = occupation.await()
                val incomeResponse = income.await()

//                if (maritalResponse.isSuccess && businessResponse.isSuccess && purposeResponse.isSuccess && subPurposeResponse.isSuccess
//                    && educationResponse.isSuccess && occupationResponse.isSuccess && incomeResponse.isSuccess
//                ) {
                returnData(
                    maritalResponse,
                    businessResponse,
                    purposeResponse,
                    subPurposeResponse,
                    educationResponse,
                    occupationResponse,
                    incomeResponse
                )
//                }
            }
        } catch (e: Exception) {
            Log.d("TAG", "Error " + e.localizedMessage)
        }
    }
}