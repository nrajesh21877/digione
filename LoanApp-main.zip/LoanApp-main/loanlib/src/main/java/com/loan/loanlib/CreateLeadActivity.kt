package com.loan.loanlib

import android.app.DatePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.widget.EditText
import com.loan.loanlib.customviews.CustomSpinner
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.Toast
import androidx.lifecycle.ViewModelProviders
import com.google.android.material.textfield.TextInputLayout
import com.loan.loanlib.api.ApiHelper
import com.loan.loanlib.api.RetrofitBuilder
import com.loan.loanlib.cache.Cache
import com.loan.loanlib.helper.DialogUtil
import com.loan.loanlib.helper.Utils
import com.loan.loanlib.model.*
import com.loan.loanlib.model.Constants.Companion.DATE_FORMAT_YYYY_MM_DD
import com.loan.loanlib.viewmodel.HomeViewModel
import com.loan.loanlib.viewmodel.HomeViewModelFactory
import java.util.*
import java.util.regex.Matcher
import java.util.regex.Pattern

class CreateLeadActivity : AppCompatActivity() {

    private lateinit var viewModel: HomeViewModel

    lateinit var dobLayout: TextInputLayout
    lateinit var mobileNumber: EditText
    lateinit var panNumber: EditText
    lateinit var name: EditText
    lateinit var mGst: EditText
    lateinit var address: EditText
    lateinit var pincode: EditText
    lateinit var email: EditText
    lateinit var whatsAppNumber: EditText
    lateinit var dob: EditText
    lateinit var businessAddress: EditText
    lateinit var businessYears: EditText
    lateinit var income: EditText
    lateinit var revenue: EditText
    lateinit var loanAmount: EditText
    lateinit var save: Button
    lateinit var spinnerEducation: CustomSpinner<Education>
    lateinit var spinnerGender: CustomSpinner<String>
    lateinit var spinnerOwnership: CustomSpinner<String>
    lateinit var spinnerMaritalStatus: CustomSpinner<MaritalStatus>
    lateinit var spinnerIncome: CustomSpinner<Income>
    lateinit var spinnerOccupation: CustomSpinner<Occupation>
    lateinit var spinnerPurpose: CustomSpinner<LoanPurpose>
    lateinit var spinnerSubPurpose: CustomSpinner<LoanSubPurpose>
    lateinit var spinnerTenure: CustomSpinner<String>
    lateinit var mMasterData: MasterData
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_lead)

        viewModel = ViewModelProviders.of(
            this,
            HomeViewModelFactory(ApiHelper(RetrofitBuilder.apiService))
        )[HomeViewModel::class.java]

        mMasterData = Cache.getInstance().masterData
        dobLayout = findViewById(R.id.inputDob)
        mobileNumber = findViewById(R.id.mobile_number)
        panNumber = findViewById(R.id.pan_number)
        name = findViewById(R.id.name)
        address = findViewById(R.id.address)
        pincode = findViewById(R.id.pincode)
        email = findViewById(R.id.email)
        whatsAppNumber = findViewById(R.id.whatsapp_number)
        businessAddress = findViewById(R.id.business_address)
        businessYears = findViewById(R.id.number_of_business_years)
        dob = findViewById(R.id.dob)
        spinnerEducation = findViewById(R.id.spinner_education)
        income = findViewById(R.id.annual_income)
        revenue = findViewById(R.id.annual_turnover)
        loanAmount = findViewById(R.id.loan_amount)
        save = findViewById(R.id.save)
        mGst = findViewById(R.id.gst)
        spinnerGender = findViewById(R.id.spinner_gender)
        spinnerTenure = findViewById(R.id.spinner_tenure)
        spinnerMaritalStatus = findViewById(R.id.spinner_marital_status)
        spinnerPurpose = findViewById(R.id.spinner_loan_puropse)
        spinnerSubPurpose = findViewById(R.id.spinner_sub_puropse)
        spinnerOccupation = findViewById(R.id.spinner_occupation)
        spinnerOwnership = findViewById(R.id.spinner_business_ownership)
        spinnerIncome = findViewById(R.id.spinner_income_type)

        dobLayout.setOnClickListener {
            run {
                showDateSelectionDialog()
            }
        }
        dob.setOnClickListener {
            run {
                showDateSelectionDialog()
            }
        }
        val genders: MutableList<String> = ArrayList()
        genders.add("Male")
        genders.add("Female")
        genders.add("Others")

        val ownership: MutableList<String> = ArrayList()
        ownership.add("Own")
        ownership.add("Partnership")
        ownership.add("Family")

        val tenure: MutableList<String> = ArrayList()
        tenure.add("3")
        tenure.add("6")
        tenure.add("12")

        spinnerGender.initialize(genders) { s: String? -> s }
        spinnerTenure.initialize(tenure) { s: String? -> s }
        spinnerOwnership.initialize(ownership) { s: String? -> s }

        spinnerMaritalStatus.initialize(
            mMasterData.maritalstatus,
            MaritalStatus::maritalStatusCode
        )
        spinnerPurpose.initialize(mMasterData.loanpurpose, LoanPurpose::loanPurposeCode)
        spinnerSubPurpose.initialize(
            mMasterData.loansubpurpose,
            LoanSubPurpose::loanSubPurposeCode
        )
        spinnerOccupation.initialize(mMasterData.occupation, Occupation::occupationCode)
        spinnerEducation.initialize(mMasterData.education, Education::educationCode)
        spinnerIncome.initialize(mMasterData.income, Income::incomeTypeCode)
        save.setOnClickListener {
            if (isValid()) {
                submitDetails()
            }
        }
    }

    private fun isValid(): Boolean {
        var valid = true
        val fullName = name.text.toString()
        val pan = panNumber.text.toString()
        val mobile = mobileNumber.text.toString()
        val address = address.text.toString()
        val pincode = pincode.text.toString()
        val email = email.text.toString()
        val gst = mGst.text.toString()
        val whatsapp = whatsAppNumber.text.toString()
        val businessAddress = businessAddress.text.toString()
        val businessYears = businessYears.text.toString()
        val dob = dob.text.toString()
        val income = income.text.toString()
        val revenue = revenue.text.toString()
        val loanAmount = loanAmount.text.toString()
        if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(pan) || TextUtils.isEmpty(mobile)
            || TextUtils.isEmpty(address)
            || TextUtils.isEmpty(pincode) || TextUtils.isEmpty(email) || TextUtils.isEmpty(whatsapp)
            || TextUtils.isEmpty(businessAddress) || TextUtils.isEmpty(businessYears) ||
            TextUtils.isEmpty(dob) ||
            TextUtils.isEmpty(income) || TextUtils.isEmpty(revenue) ||
            TextUtils.isEmpty(loanAmount) || TextUtils.isEmpty(gst)
        ) {
            valid = false
            Toast.makeText(this, "All Fields Are Mandatory", Toast.LENGTH_SHORT).show()
        } else if (!isValidGSTNo(gst)) {
            valid = false
            Toast.makeText(this, "Please enter valid GST/CIN no", Toast.LENGTH_SHORT).show()
        }
        return valid
    }

    private fun submitDetails() {
        val details = getDetails()
        DialogUtil.displayProgress(this)
        viewModel.submitLead(details).observe(this, {
            run {
                if (it.data != null) {
                    Toast.makeText(this, it.data.statusMessage, Toast.LENGTH_SHORT).show()
                    val i = Intent(applicationContext, LeadListActivity::class.java)
                    startActivity(i)
                    finish()
                }
            }
        })
    }

    var dateforvalid: String = ""
    private fun showDateSelectionDialog() {
        val c = Calendar.getInstance()
        c.add(Calendar.DATE, 1)
        val mYear = c[Calendar.YEAR]
        val mMonth = c[Calendar.MONTH]
        val mDay = c[Calendar.DAY_OF_MONTH]
        val datePickerDialog = DatePickerDialog(
            this,
            { _, year, monthOfYear, dayOfMonth ->
                val enteredValue = Calendar.getInstance()
                enteredValue[year, monthOfYear] = dayOfMonth
                val min = Calendar.getInstance()
                min.add(Calendar.DATE, 0)
                val max = Calendar.getInstance()
                max.add(Calendar.DATE, 30)
                if (min < enteredValue && max > enteredValue) {
                    dateforvalid = (Utils.getStringFromDate(
                        enteredValue.time,
                        DATE_FORMAT_YYYY_MM_DD
                    ))
                    dob.setText(dateforvalid)
                } else {
                    dateforvalid = (Utils.getStringFromDate(
                        enteredValue.time,
                        DATE_FORMAT_YYYY_MM_DD
                    ))
                    dob.setText(dateforvalid)
                }
            }, mYear, mMonth, mDay
        )
        val max = Calendar.getInstance()
        max.add(Calendar.DATE, 29)
        val min = Calendar.getInstance()
        min.add(Calendar.DATE, 0)
        min.add(Calendar.MINUTE, -1)
        datePickerDialog.datePicker.maxDate = max.timeInMillis
        datePickerDialog.datePicker.minDate = min.timeInMillis
        datePickerDialog.show()
    }


    private fun getDetails(): LeadDetails {

        val fullName = name.text.toString()
        val pan = panNumber.text.toString()
        val mobile = mobileNumber.text.toString()
        val address = address.text.toString()
        val pincode = pincode.text.toString()
        val email = email.text.toString()
        val whatsapp = whatsAppNumber.text.toString()
        val businessAddress = businessAddress.text.toString()
        val businessYears = businessYears.text.toString()
        val dob = dob.text.toString()
        val education = spinnerEducation.value
        val income = income.text.toString().toLong()
        val revenue = revenue.text.toString().toLong()
        val loanAmount = loanAmount.text.toString()
        val gender = spinnerGender.value
        val tenure = spinnerTenure.value
        val gst = mGst.text.toString()

        val maritalStatus = spinnerMaritalStatus.value
        val (_, loanPurposeId) = spinnerPurpose.value
        val (_, _, loanSubPurposeId) = spinnerSubPurpose.value
        val occupationCode = spinnerOccupation.spinner.selectedItemPosition
        val ownership = spinnerOwnership.spinner.selectedItemPosition
        val (_, incomeTypeId) = spinnerIncome.value
        val details = LeadDetails()
        details.mobilenumber = mobile
        details.leadName = fullName
        details.panno = pan
        details.permanentAddress = address
        details.email = email
        details.whatsAppNo = whatsapp
        details.gender = gender
        details.dob = dob
        details.educationCode = education.eduId
        details.businessAddressPIN = pincode
        details.maritalStatus = maritalStatus.maritalStatusId
        details.occupationType = occupationCode
        details.businessOwnerShipType = ownership
        details.businessAddress = businessAddress
        details.noOfYrInBusiness = Integer.valueOf(businessYears)
        details.incomeType = incomeTypeId
        details.annualIncome = income
        details.gstCin = gst
        details.annualTurnover = revenue
        details.loanPurpose = loanPurposeId
        details.subLoanPurpose = loanSubPurposeId
        details.loanAmountRequired = loanAmount.toLong()
        details.repaymentTenure = Integer.valueOf(tenure)
        return details
    }

    fun isValidGSTNo(str: String?): Boolean {
        // Regex to check valid
        // GST (Goods and Services Tax) number
        val regex = ("^[0-9]{2}[A-Z]{5}[0-9]{4}"
                + "[A-Z]{1}[1-9A-Z]{1}"
                + "Z[0-9A-Z]{1}$")

        // Compile the ReGex
        val p: Pattern = Pattern.compile(regex)

        // If the string is empty
        // return false
        if (str == null) {
            return false
        }

        // Pattern class contains matcher()
        // method to find the matching
        // between the given string
        // and the regular expression.
        val m: Matcher = p.matcher(str)

        // Return if the string
        // matched the ReGex
        return m.matches()
    }
}