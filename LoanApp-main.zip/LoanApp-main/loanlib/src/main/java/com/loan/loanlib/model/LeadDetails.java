package com.loan.loanlib.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LeadDetails {

    @SerializedName("LeadSqId")
    @Expose
    private Integer leadSqId;
    @SerializedName("Mobilenumber")
    @Expose
    private String mobilenumber;
    @SerializedName("LeadName")
    @Expose
    private String leadName;
    @SerializedName("PANNO")
    @Expose
    private String panno;
    @SerializedName("PermanentAddress")
    @Expose
    private String permanentAddress;
    @SerializedName("ResidenceAddress")
    @Expose
    private String residenceAddress;
    @SerializedName("CorrespondenseAddress")
    @Expose
    private String correspondenseAddress;
    @SerializedName("Email")
    @Expose
    private String email;
    @SerializedName("WhatsAppNo")
    @Expose
    private String whatsAppNo;
    @SerializedName("Gender")
    @Expose
    private String gender;
    @SerializedName("DOB")
    @Expose
    private String dob;
    @SerializedName("MaritalStatus")
    @Expose
    private Integer maritalStatus;
    @SerializedName("EducationCode")
    @Expose
    private Integer educationCode;
    @SerializedName("BusinessAddressPIN")
    @Expose
    private String businessAddressPIN;
    @SerializedName("BusinessLatitude")
    @Expose
    private String businessLatitude;
    @SerializedName("BusinessLongitude")
    @Expose
    private String businessLongitude;
    @SerializedName("OccupationType")
    @Expose
    private Integer occupationType;
    @SerializedName("GST_CIN")
    @Expose
    private String gstCin;
    @SerializedName("BusinessOwnerShipType")
    @Expose
    private Integer businessOwnerShipType;
    @SerializedName("BusinessAddress")
    @Expose
    private String businessAddress;
    @SerializedName("NoOfYrInBusiness")
    @Expose
    private Integer noOfYrInBusiness;
    @SerializedName("IncomeType")
    @Expose
    private Integer incomeType;
    @SerializedName("AnnualIncome")
    @Expose
    private Long annualIncome;
    @SerializedName("AnnualTurnover")
    @Expose
    private Long annualTurnover;
    @SerializedName("LoanPurpose")
    @Expose
    private Integer loanPurpose;
    @SerializedName("SubLoanPurpose")
    @Expose
    private Integer subLoanPurpose;
    @SerializedName("LoanAmountRequired")
    @Expose
    private Long loanAmountRequired;
    @SerializedName("RepaymentTenure")
    @Expose
    private Integer repaymentTenure;
    @SerializedName("Latitude")
    @Expose
    private String latitude;
    @SerializedName("Longitude")
    @Expose
    private String longitude;
    @SerializedName("CreatedById")
    @Expose
    private String createdById = "288992989";
    @SerializedName("CreatedByPartnerId")
    @Expose
    private String createdByPartnerId = "p399";
    @SerializedName("UniqueId")
    @Expose
    private String uniqueId;
    @SerializedName("ServiceName")
    @Expose
    private String serviceName;
    @SerializedName("CreatedDate")
    @Expose
    private String createdDate;
    @SerializedName("CreatedBy")
    @Expose
    private String createdBy;

    public LeadDetails() {
    }

    public Integer getLeadSqId() {
        return leadSqId;
    }

    public void setLeadSqId(Integer leadSqId) {
        this.leadSqId = leadSqId;
    }

    public String getMobilenumber() {
        return mobilenumber;
    }

    public void setMobilenumber(String mobilenumber) {
        this.mobilenumber = mobilenumber;
    }

    public String getLeadName() {
        return leadName;
    }

    public void setLeadName(String leadName) {
        this.leadName = leadName;
    }

    public String getPanno() {
        return panno;
    }

    public void setPanno(String panno) {
        this.panno = panno;
    }

    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    public String getResidenceAddress() {
        return residenceAddress;
    }

    public void setResidenceAddress(String residenceAddress) {
        this.residenceAddress = residenceAddress;
    }

    public String getCorrespondenseAddress() {
        return correspondenseAddress;
    }

    public void setCorrespondenseAddress(String correspondenseAddress) {
        this.correspondenseAddress = correspondenseAddress;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWhatsAppNo() {
        return whatsAppNo;
    }

    public void setWhatsAppNo(String whatsAppNo) {
        this.whatsAppNo = whatsAppNo;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public Integer getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(Integer maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public Integer getEducationCode() {
        return educationCode;
    }

    public void setEducationCode(Integer educationCode) {
        this.educationCode = educationCode;
    }

    public String getBusinessAddressPIN() {
        return businessAddressPIN;
    }

    public void setBusinessAddressPIN(String businessAddressPIN) {
        this.businessAddressPIN = businessAddressPIN;
    }

    public String getBusinessLatitude() {
        return businessLatitude;
    }

    public void setBusinessLatitude(String businessLatitude) {
        this.businessLatitude = businessLatitude;
    }

    public String getBusinessLongitude() {
        return businessLongitude;
    }

    public void setBusinessLongitude(String businessLongitude) {
        this.businessLongitude = businessLongitude;
    }

    public Integer getOccupationType() {
        return occupationType;
    }

    public void setOccupationType(Integer occupationType) {
        this.occupationType = occupationType;
    }

    public String getGstCin() {
        return gstCin;
    }

    public void setGstCin(String gstCin) {
        this.gstCin = gstCin;
    }

    public Integer getBusinessOwnerShipType() {
        return businessOwnerShipType;
    }

    public void setBusinessOwnerShipType(Integer businessOwnerShipType) {
        this.businessOwnerShipType = businessOwnerShipType;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public Integer getNoOfYrInBusiness() {
        return noOfYrInBusiness;
    }

    public void setNoOfYrInBusiness(Integer noOfYrInBusiness) {
        this.noOfYrInBusiness = noOfYrInBusiness;
    }

    public Integer getIncomeType() {
        return incomeType;
    }

    public void setIncomeType(Integer incomeType) {
        this.incomeType = incomeType;
    }

    public Long getAnnualIncome() {
        return annualIncome;
    }

    public void setAnnualIncome(Long annualIncome) {
        this.annualIncome = annualIncome;
    }

    public Long getAnnualTurnover() {
        return annualTurnover;
    }

    public void setAnnualTurnover(Long annualTurnover) {
        this.annualTurnover = annualTurnover;
    }

    public Integer getLoanPurpose() {
        return loanPurpose;
    }

    public void setLoanPurpose(Integer loanPurpose) {
        this.loanPurpose = loanPurpose;
    }

    public Integer getSubLoanPurpose() {
        return subLoanPurpose;
    }

    public void setSubLoanPurpose(Integer subLoanPurpose) {
        this.subLoanPurpose = subLoanPurpose;
    }

    public Long getLoanAmountRequired() {
        return loanAmountRequired;
    }

    public void setLoanAmountRequired(Long loanAmountRequired) {
        this.loanAmountRequired = loanAmountRequired;
    }

    public Integer getRepaymentTenure() {
        return repaymentTenure;
    }

    public void setRepaymentTenure(Integer repaymentTenure) {
        this.repaymentTenure = repaymentTenure;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getCreatedById() {
        return createdById;
    }

    public void setCreatedById(String createdById) {
        this.createdById = createdById;
    }

    public String getCreatedByPartnerId() {
        return createdByPartnerId;
    }

    public void setCreatedByPartnerId(String createdByPartnerId) {
        this.createdByPartnerId = createdByPartnerId;
    }

    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

}
