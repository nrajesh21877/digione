package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class MasterData(
    @SerializedName("education")
    val education: List<Education>,
    @SerializedName("income")
    val income: List<Income>,
    @SerializedName("loanpurpose")
    val loanpurpose: List<LoanPurpose>,
    @SerializedName("loansubpurpose")
    val loansubpurpose: List<LoanSubPurpose>,
    @SerializedName("maritalstatus")
    val maritalstatus: List<MaritalStatus>,
    @SerializedName("occupation")
    val occupation: List<Occupation>
)