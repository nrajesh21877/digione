package com.loan.loanlib

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.content.Intent
import android.widget.Button
import androidx.lifecycle.ViewModelProviders
import com.loan.loanlib.api.ApiHelper
import com.loan.loanlib.api.RetrofitBuilder
import com.loan.loanlib.cache.Cache
import com.loan.loanlib.helper.DialogUtil
import com.loan.loanlib.viewmodel.HomeViewModel
import com.loan.loanlib.viewmodel.HomeViewModelFactory

class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: HomeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.lib_main)
        viewModel = ViewModelProviders.of(
            this,
            HomeViewModelFactory(ApiHelper(RetrofitBuilder.apiService))
        )[HomeViewModel::class.java]

        val parternerId = intent.getStringExtra("partnerID")
        val mobileNumber = intent.getStringExtra("mobile")
        val create_lead = findViewById<Button>(R.id.create_lead)
        val view_lead = findViewById<Button>(R.id.view_lead)
        val partnerid = findViewById<TextView>(R.id.partnerid)
        val key = findViewById<TextView>(R.id.key)
        partnerid.text = "PartnerID : $parternerId"
        key.text = "Key : $mobileNumber"
        create_lead.setOnClickListener {
            startActivity(
                Intent(
                    applicationContext, CreateLeadActivity::class.java
                )
            )
        }
        view_lead.setOnClickListener {
            startActivity(
                Intent(
                    applicationContext, LeadListActivity::class.java
                )
            )
        }
        DialogUtil.displayProgress(this)
        viewModel.getMasterData().observe(this, {
            run {
                if (it.data != null) {
                    val masterData = it.data
                    Cache.getInstance().masterData = masterData
                    println("Success " + Cache.getInstance().masterData.maritalstatus[0].maritalStatusCode)
                }
            }
        })
    }
}