package com.loan.loanlib.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.loan.loanlib.helper.DialogUtil
import com.loan.loanlib.interfaces.Resource
import com.loan.loanlib.model.LeadDetails
import com.loan.loanlib.repository.ApiRepository
import kotlinx.coroutines.Dispatchers

class WeatherViewModel(private val repository: ApiRepository) : ViewModel() {

    fun getLatLng(zip: String) = liveData(Dispatchers.IO) {
        emit(Resource.loading(data = null))
        try {
            val response = repository.getLatLng(zip, "f659274e9bc0179033fb265b47bedab3")
            emit(Resource.success(data = response))
            DialogUtil.stopProgressDisplay()
        } catch (exception: Exception) {
            emit(Resource.error(data = null, message = exception.message ?: "Error! "))
            DialogUtil.stopProgressDisplay()
        }
    }
}