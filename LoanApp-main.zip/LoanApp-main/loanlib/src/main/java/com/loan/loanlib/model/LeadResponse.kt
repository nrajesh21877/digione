package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class LeadResponse(
    @SerializedName("ResponseCode")
    val responseCode: String,
    @SerializedName("ResponseMessage")
    val responseMessage: String,
    @SerializedName("StatusCode")
    val statusCode: String,
    @SerializedName("StatusMessage")
    val statusMessage: String,
    @SerializedName("UniqueId")
    val uniqueId: String
)