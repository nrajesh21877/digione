package com.loan.loanlib

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.RecyclerView
import com.loan.loanlib.adapter.LeadAdapter
import androidx.recyclerview.widget.LinearLayoutManager
import com.loan.loanlib.api.ApiHelper
import com.loan.loanlib.api.RetrofitBuilder
import com.loan.loanlib.helper.DialogUtil
import com.loan.loanlib.model.Constants
import com.loan.loanlib.model.LeadSummary
import com.loan.loanlib.viewmodel.HomeViewModel
import com.loan.loanlib.viewmodel.HomeViewModelFactory

class LeadListActivity : AppCompatActivity(), LeadAdapter.ItemClickListener {
    private lateinit var viewModel: HomeViewModel
    private lateinit var mLeads: ArrayList<LeadSummary>;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_view_leads)
        viewModel = ViewModelProviders.of(
            this,
            HomeViewModelFactory(ApiHelper(RetrofitBuilder.apiService))
        )[HomeViewModel::class.java]

        DialogUtil.displayProgress(this)
        viewModel.fetchLeads().observe(this, {
            run {
                if (it.data != null) {
                    mLeads = it.data as ArrayList<LeadSummary>
                    showLeads(mLeads)
                }
            }
        })

    }

    private fun showLeads(leads: ArrayList<LeadSummary>) {
        val recyclerView = findViewById<RecyclerView>(R.id.lead_view)
        val adapter = LeadAdapter(leads, this)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        adapter.notifyDataSetChanged()
    }

    override fun onSelected(lead: LeadSummary) {
        val i = Intent(applicationContext, LeadDetailsActivity::class.java)
        i.putExtra("SQID", lead.leadSqId.toString())
        startActivity(i)
    }


}