package com.loan.loanlib.ui.main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.loan.loanlib.LeadDetailsActivity
import com.loan.loanlib.R
import com.loan.loanlib.adapter.LeadAdapter
import com.loan.loanlib.api.ApiHelper
import com.loan.loanlib.api.RetrofitBuilder
import com.loan.loanlib.helper.DialogUtil
import com.loan.loanlib.model.LeadSummary
import com.loan.loanlib.viewmodel.HomeViewModel
import com.loan.loanlib.viewmodel.HomeViewModelFactory

class LeadsListFragment : Fragment(), LeadAdapter.ItemClickListener {
    private lateinit var viewModel: HomeViewModel
    private lateinit var mLeads: ArrayList<LeadSummary>;
    private lateinit var recyclerView: RecyclerView;

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"

        @JvmStatic
        fun newInstance(sectionNumber: Int): LeadsListFragment {
            return LeadsListFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_SECTION_NUMBER, sectionNumber)
                }
            }
        }
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        super.setUserVisibleHint(isVisibleToUser)
        if (isVisibleToUser) {
            Log.d("LEADS", "fragment is visible to user")
            fetchLeads()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view: View = inflater.inflate(R.layout.fragment_leads, container, false)
        viewModel = ViewModelProviders.of(
            this,
            HomeViewModelFactory(ApiHelper(RetrofitBuilder.apiService))
        )[HomeViewModel::class.java]

        recyclerView = view.findViewById(R.id.lead_view)
        DialogUtil.displayProgress(requireActivity())
        fetchLeads()
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        return view
    }

    fun fetchLeads() {
        viewModel.fetchLeads().observe(requireActivity(), {
            run {
                if (it.data != null) {
                    mLeads = it.data as ArrayList<LeadSummary>
                    Log.d("LEADS", "leads featched")
                    showLeads(mLeads)
                }
            }
        })
    }

    private fun showLeads(leads: ArrayList<LeadSummary>) {
        val adapter = LeadAdapter(leads, this)
        recyclerView.adapter = adapter
        adapter.notifyDataSetChanged()
    }

    override fun onSelected(lead: LeadSummary) {
        val i = Intent(requireActivity(), LeadDetailsActivity::class.java)
        i.putExtra("SQID", lead.leadSqId.toString())
        startActivity(i)
    }
}