package com.loan.loanlib.api

import com.loan.loanlib.model.*
import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    @POST("workflow/leadsubmit")
    suspend fun leadSubmit(@Body lead: LeadDetails): LeadResponse

    @GET("workflow/getLeadSummary/288992989/p399")
    suspend fun getLeadSummary(): List<LeadSummary>

    @GET("workflow/getLeadDetails/{sqid}")
    suspend fun getLeadDetails(@Path("sqid") sqid: String): List<LeadDetails>

    @GET("master/LoanPurpose")
    suspend fun loanPurpose(): List<LoanPurpose>

    @GET("master/LoansubPurpose")
    suspend fun loanSubPurpose(): List<LoanSubPurpose>

    @GET("master/MaritalStatus")
    suspend fun maritalStatus(): List<MaritalStatus>

    @GET("master/Education")
    suspend fun education(): List<Education>

    @GET("master/Occupation")
    suspend fun occupation(): List<Occupation>

    @GET("master/Business")
    suspend fun business(): List<Business>

    @GET("master/Income")
    suspend fun income(): List<Income>

    @GET("master/getMasters")
    suspend fun getMasterData(): MasterData

    @POST("weather")
    suspend fun getLatLng(@Query("zip") zip: String, @Query("appid") appid: String): Root

}