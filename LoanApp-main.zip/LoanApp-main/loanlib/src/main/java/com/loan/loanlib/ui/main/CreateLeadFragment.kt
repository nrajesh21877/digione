package com.loan.loanlib.ui.main

import android.app.DatePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import com.google.android.material.textfield.TextInputLayout
import com.loan.loanlib.R
import com.loan.loanlib.api.ApiHelper
import com.loan.loanlib.api.RetrofitBuilder
import com.loan.loanlib.api.WeatherRetrofitBuilder
import com.loan.loanlib.cache.Cache
import com.loan.loanlib.customviews.CustomSpinner
import com.loan.loanlib.helper.DialogUtil
import com.loan.loanlib.helper.Utils
import com.loan.loanlib.model.*
import com.loan.loanlib.viewmodel.HomeViewModel
import com.loan.loanlib.viewmodel.HomeViewModelFactory
import com.loan.loanlib.viewmodel.WeatherViewModel
import com.loan.loanlib.viewmodel.WeatherViewModelFactory
import java.util.*
import java.util.regex.Matcher
import java.util.regex.Pattern

class CreateLeadFragment : Fragment() {

    private lateinit var viewModel: HomeViewModel
    private lateinit var weatherViewModel: WeatherViewModel

    companion object {
        private const val ARG_SECTION_NUMBER = "section_number"

        @JvmStatic
        fun newInstance(sectionNumber: Int): CreateLeadFragment {
            return CreateLeadFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_SECTION_NUMBER, sectionNumber)
                }
            }
        }
    }

    lateinit var dobLayout: TextInputLayout
    lateinit var mobileNumber: EditText
    lateinit var panNumber: EditText
    lateinit var name: EditText
    lateinit var mGst: EditText
    lateinit var address: EditText
    lateinit var pincode: EditText
    lateinit var email: EditText
    lateinit var whatsAppNumber: EditText
    lateinit var dob: EditText
    lateinit var businessAddress: EditText
    lateinit var businessYears: EditText
    lateinit var income: EditText
    lateinit var revenue: EditText
    lateinit var loanAmount: EditText
    lateinit var save: Button
    lateinit var spinnerEducation: CustomSpinner<Education>
    lateinit var spinnerGender: CustomSpinner<String>
    lateinit var spinnerOwnership: CustomSpinner<String>
    lateinit var spinnerMaritalStatus: CustomSpinner<MaritalStatus>
    lateinit var spinnerIncome: CustomSpinner<Income>
    lateinit var spinnerOccupation: CustomSpinner<Occupation>
    lateinit var spinnerPurpose: CustomSpinner<LoanPurpose>
    lateinit var spinnerSubPurpose: CustomSpinner<LoanSubPurpose>
    lateinit var spinnerTenure: CustomSpinner<String>
    lateinit var mMasterData: MasterData
    var mLat: String = ""
    var mLng: String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view: View = inflater.inflate(R.layout.fragment_create_lead, container, false)

        viewModel = ViewModelProviders.of(
            this,
            HomeViewModelFactory(ApiHelper(RetrofitBuilder.apiService))
        )[HomeViewModel::class.java]

        weatherViewModel = ViewModelProviders.of(
            this,
            WeatherViewModelFactory(ApiHelper(WeatherRetrofitBuilder.apiService))
        )[WeatherViewModel::class.java]

        mMasterData = Cache.getInstance().masterData
        dobLayout = view.findViewById(R.id.inputDob)
        mobileNumber = view.findViewById(R.id.mobile_number)
        panNumber = view.findViewById(R.id.pan_number)
        name = view.findViewById(R.id.name)
        address = view.findViewById(R.id.address)
        pincode = view.findViewById(R.id.pincode)
        email = view.findViewById(R.id.email)
        whatsAppNumber = view.findViewById(R.id.whatsapp_number)
        businessAddress = view.findViewById(R.id.business_address)
        businessYears = view.findViewById(R.id.number_of_business_years)
        dob = view.findViewById(R.id.dob)
        spinnerEducation = view.findViewById(R.id.spinner_education)
        income = view.findViewById(R.id.annual_income)
        revenue = view.findViewById(R.id.annual_turnover)
        loanAmount = view.findViewById(R.id.loan_amount)
        save = view.findViewById(R.id.save)
        mGst = view.findViewById(R.id.gst)
        spinnerGender = view.findViewById(R.id.spinner_gender)
        spinnerTenure = view.findViewById(R.id.spinner_tenure)
        spinnerMaritalStatus = view.findViewById(R.id.spinner_marital_status)
        spinnerPurpose = view.findViewById(R.id.spinner_loan_puropse)
        spinnerSubPurpose = view.findViewById(R.id.spinner_sub_puropse)
        spinnerOccupation = view.findViewById(R.id.spinner_occupation)
        spinnerOwnership = view.findViewById(R.id.spinner_business_ownership)
        spinnerIncome = view.findViewById(R.id.spinner_income_type)

        dobLayout.setOnClickListener {
            run {
                showDatePicker(0)
            }
        }

        dob.setOnClickListener {
            run {
                showDatePicker(0)
            }
        }

        val genders: MutableList<String> = ArrayList()
        genders.add("Male")
        genders.add("Female")
        genders.add("Others")

        val ownership: MutableList<String> = ArrayList()
        ownership.add("Own")
        ownership.add("Partnership")
        ownership.add("Family")

        val tenure: MutableList<String> = ArrayList()
        tenure.add("3")
        tenure.add("6")
        tenure.add("9")
        tenure.add("12")
        tenure.add("18")
        tenure.add("24")
        tenure.add("30")
        tenure.add("36")

        spinnerGender.initialize(genders) { s: String? -> s }
        spinnerTenure.initialize(tenure) { s: String? -> s }
        spinnerOwnership.initialize(ownership) { s: String? -> s }

        spinnerMaritalStatus.initialize(
            mMasterData.maritalstatus,
            MaritalStatus::maritalStatusCode
        )
        spinnerPurpose.initialize(mMasterData.loanpurpose, LoanPurpose::loanPurposeCode)
        spinnerSubPurpose.initialize(
            mMasterData.loansubpurpose,
            LoanSubPurpose::loanSubPurposeCode
        )
        spinnerOccupation.initialize(mMasterData.occupation, Occupation::occupationCode)
        spinnerEducation.initialize(mMasterData.education, Education::educationCode)
        spinnerIncome.initialize(mMasterData.income, Income::incomeTypeCode)
        save.setOnClickListener {
            if (isValid()) {
                submitDetails()
            }
        }

        pincode.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                if (p0!!.length == 6) {
                    val pin = pincode.text.toString() + ",in"
                    fetchLatLng(pin)
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

        })
        return view
    }

    private fun fetchLatLng(pin: String) {
        DialogUtil.displayProgress(requireActivity())
        weatherViewModel.getLatLng(pin).observe(requireActivity(), {
            run {
                if (it.data != null) {
                    val coord = it.data.coord
                    mLat = coord!!.lat.toString()
                    mLng = coord.lon.toString()
                }
            }
        })
    }

    private fun isValid(): Boolean {
        var valid = true
        val fullName = name.text.toString()
        val pan = panNumber.text.toString()
        val mobile = mobileNumber.text.toString()
        val address = address.text.toString()
        val pincode = pincode.text.toString()
        val email = email.text.toString()
        val gst = mGst.text.toString()
        val whatsapp = whatsAppNumber.text.toString()
        val businessAddress = businessAddress.text.toString()
        val businessYears = businessYears.text.toString()
        val dob = dob.text.toString()
        val income = income.text.toString()
        val revenue = revenue.text.toString()
        val loanAmount = loanAmount.text.toString()
        if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(pan) || TextUtils.isEmpty(mobile)
            || TextUtils.isEmpty(address)
            || TextUtils.isEmpty(pincode) || TextUtils.isEmpty(email) || TextUtils.isEmpty(whatsapp)
            || TextUtils.isEmpty(businessAddress) || TextUtils.isEmpty(businessYears) ||
            TextUtils.isEmpty(dob) ||
            TextUtils.isEmpty(income) || TextUtils.isEmpty(revenue) ||
            TextUtils.isEmpty(loanAmount) || TextUtils.isEmpty(gst)
        ) {
            valid = false
            Toast.makeText(requireActivity(), "All Fields Are Mandatory", Toast.LENGTH_SHORT).show()

        } else if (mobileNumber.text.toString().length < 10) {
            valid = false
            Toast.makeText(requireActivity(), "Invalid mobile number", Toast.LENGTH_SHORT)
                .show()
        } else if (!isValidPan(pan)) {
            valid = false
            Toast.makeText(requireActivity(), "Please enter valid Pan no", Toast.LENGTH_SHORT)
                .show()
        } else if (whatsapp.length < 10) {
            valid = false
            Toast.makeText(requireActivity(), "Invalid whats app number", Toast.LENGTH_SHORT)
                .show()
        } else if (!isValidGSTNo(gst)) {
            valid = false
            Toast.makeText(requireActivity(), "Please enter valid GST no", Toast.LENGTH_SHORT)
                .show()
        } else if (!Utils.isValidEmail(email)) {
            valid = false
            Toast.makeText(requireActivity(), "Invalid Email Id", Toast.LENGTH_SHORT)
                .show()
        } else if (TextUtils.isEmpty(mLat) || TextUtils.isEmpty(mLng)) {
            valid = false
            Toast.makeText(requireActivity(), "Pin Code is empty or Invalid", Toast.LENGTH_SHORT)
                .show()
        }

        return valid
    }

    fun isValidPan(pan: String?): Boolean {
        val pattern: Pattern = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");

        val matcher = pattern.matcher(pan);
        if (pan == null) {
            return false
        }
        return matcher.matches();
    }

    fun isValidGSTNo(str: String?): Boolean {
        // Regex to check valid
        // GST (Goods and Services Tax) number
        val regex = ("^[0-9]{2}[A-Z]{5}[0-9]{4}"
                + "[A-Z]{1}[1-9A-Z]{1}"
                + "Z[0-9A-Z]{1}$")

        // Compile the ReGex
        val p: Pattern = Pattern.compile(regex)

        // If the string is empty
        // return false
        if (str == null) {
            return false
        }

        // Pattern class contains matcher()
        // method to find the matching
        // between the given string
        // and the regular expression.
        val m: Matcher = p.matcher(str)

        // Return if the string
        // matched the ReGex
        return m.matches()
    }

    private fun submitDetails() {
        val details = getDetails()
        DialogUtil.displayProgress(requireActivity())
        viewModel.submitLead(details).observe(requireActivity(), {
            run {
                if (it.data != null) {
                    Toast.makeText(
                        requireActivity(),
                        "Create Lead Submitted Successfully.",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                    name.setText("")
                    panNumber.setText("")
                    mobileNumber.setText("")
                    whatsAppNumber.setText("")
                    address.setText("")
                    pincode.setText("")
                    email.setText("")
                    businessAddress.setText("")
                    businessYears.setText("")
                    dob.setText("")
                    income.setText("")
                    revenue.setText("")
                    loanAmount.setText("")
                    mGst.setText("")
                    mLat = ""
                    mLng = ""
                }
            }
        })
    }

    var dateforvalid: String = ""
    private var startDate: Calendar? = null
    private lateinit var endDate: Calendar
    private lateinit var currentDate: Calendar
    private fun showDatePicker(type: Int) {
        if (type == 0) {
            dob = dob
            val cal = Calendar.getInstance()
            cal.add(Calendar.YEAR, -100)
            startDate = cal //Calendar.getInstance();;
            endDate = Calendar.getInstance()
//            endDate = [Calendar.YEAR-1]
//            cal.set(2021, 12, 31)
            currentDate = endDate
            val picker = DatePickerDialog(
                requireActivity(),
                { _, i, i1, i2 ->
                    val cal = Calendar.getInstance()
                    cal[Calendar.YEAR] = i
                    cal[Calendar.MONTH] = i1
                    cal[Calendar.DAY_OF_MONTH] = i2
                    dob.setText(Utils.getStringFromDate(cal.time, Constants.DATE_FORMAT_YYYY_MM_DD))
                    dob.clearFocus()
                },
                currentDate[Calendar.YEAR],
                currentDate[Calendar.MONTH],
                currentDate[Calendar.DATE]
            )
            picker.datePicker.minDate = startDate!!.time.time
            picker.datePicker.maxDate = endDate.time.time
            picker.show()
        } else {
            val enteredTime = dob.text.toString()
            val dt: Date? = Utils.getDateFromString(enteredTime, Constants.DATE_FORMAT_YYYY_MM_DD)
            val cal = Calendar.getInstance()
            cal.time = dt
            startDate = cal
            val cal1 = Calendar.getInstance()
            cal1.time = dt
            cal1.add(Calendar.DATE, 30)
            currentDate = Calendar.getInstance()
            endDate = if (cal1.compareTo(currentDate) > 0) {
                currentDate
            } else {
                cal1
            }
//            to_date = to_date
            val picker = DatePickerDialog(
                requireActivity(),
                { _, i, i1, i2 ->
                    val cal = Calendar.getInstance()
                    cal[Calendar.YEAR] = i
                    cal[Calendar.MONTH] = i1
                    cal[Calendar.DAY_OF_MONTH] = i2
                },
                currentDate.get(Calendar.YEAR),
                currentDate.get(Calendar.MONTH),
                currentDate.get(Calendar.DATE)
            )
            picker.datePicker.minDate = startDate!!.time.time
            picker.datePicker.maxDate = endDate.time.time
            picker.show()
        }
    }

    private fun showDateSelectionDialog() {
        val c = Calendar.getInstance()
        c.add(Calendar.DATE, -100)
        val mYear = c[Calendar.YEAR]
        val mMonth = c[Calendar.MONTH]
        val mDay = c[Calendar.DAY_OF_MONTH]
        val datePickerDialog = DatePickerDialog(
            requireActivity(),
            { _, year, monthOfYear, dayOfMonth ->
                val enteredValue = Calendar.getInstance()
                enteredValue[year, monthOfYear] = dayOfMonth
                val min = Calendar.getInstance()
                min.add(Calendar.DATE, 0)
                val max = Calendar.getInstance()
                max.add(Calendar.DATE, 30)
                if (min < enteredValue && max > enteredValue) {
                    dateforvalid = (Utils.getStringFromDate(
                        enteredValue.time,
                        Constants.DATE_FORMAT_YYYY_MM_DD
                    ))
                    dob.setText(dateforvalid)
                } else {
                    dateforvalid = (Utils.getStringFromDate(
                        enteredValue.time,
                        Constants.DATE_FORMAT_YYYY_MM_DD
                    ))
                    dob.setText(dateforvalid)
                }
            }, mYear, mMonth, mDay
        )
        val max = Calendar.getInstance()
        max.add(Calendar.DATE, 29)
        val min = Calendar.getInstance()
        min.add(Calendar.DATE, 0)
        min.add(Calendar.MINUTE, -1)
        datePickerDialog.datePicker.maxDate = max.timeInMillis
        datePickerDialog.datePicker.minDate = min.timeInMillis
        datePickerDialog.show()
    }

    private fun getDetails(): LeadDetails {

        val fullName = name.text.toString()
        val pan = panNumber.text.toString()
        val mobile = mobileNumber.text.toString()
        val address = address.text.toString()
        val pincode = pincode.text.toString()
        val email = email.text.toString()
        val whatsapp = whatsAppNumber.text.toString()
        val businessAddress = businessAddress.text.toString()
        val businessYears = businessYears.text.toString()
        val dob = dob.text.toString()
        val education = spinnerEducation.value
        val income = income.text.toString().toLong()
        val revenue = revenue.text.toString().toLong()
        val loanAmount = loanAmount.text.toString()
        val gender = spinnerGender.value
        val tenure = spinnerTenure.value
        val gst = mGst.text.toString()

        val maritalStatus = spinnerMaritalStatus.value
        val (_, loanPurposeId) = spinnerPurpose.value
        val (_, _, loanSubPurposeId) = spinnerSubPurpose.value
        val occupationCode = spinnerOccupation.spinner.selectedItemPosition
        val ownership = spinnerOwnership.spinner.selectedItemPosition
        val (_, incomeTypeId) = spinnerIncome.value
        val details = LeadDetails()
        details.mobilenumber = mobile
        details.leadName = fullName
        details.panno = pan
        details.permanentAddress = address
        details.email = email
        details.whatsAppNo = whatsapp
        details.gender = gender
        details.dob = dob
        details.latitude = mLat
        details.longitude = mLng
        details.businessLatitude = mLat
        details.businessLongitude = mLng
        details.educationCode = education.eduId
        details.businessAddressPIN = pincode
        details.maritalStatus = maritalStatus.maritalStatusId
        details.occupationType = occupationCode
        details.businessOwnerShipType = ownership
        details.businessAddress = businessAddress
        details.noOfYrInBusiness = Integer.valueOf(businessYears)
        details.incomeType = incomeTypeId
        details.annualIncome = income
        details.gstCin = gst
        details.annualTurnover = revenue
        details.loanPurpose = loanPurposeId
        details.subLoanPurpose = loanSubPurposeId
        details.loanAmountRequired = loanAmount.toLong()
        details.repaymentTenure = Integer.valueOf(tenure)
        return details
    }
}