package com.loan.loanlib.model

class Constants {
    companion object {
        const val DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd"
        const val DATE_FORMAT_DD_MM_YYYY = "dd-MM-yyyy"
        const val SQID = "sqId"
    }
}