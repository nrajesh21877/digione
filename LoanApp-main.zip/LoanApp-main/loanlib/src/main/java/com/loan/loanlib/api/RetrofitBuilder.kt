package com.loan.loanlib.api

import com.loan.loanlib.BuildConfig
import okhttp3.*
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.OkHttpClient


object RetrofitBuilder {

    private const val BASE_URL = BuildConfig.BASE_URL

    var httpClient: OkHttpClient =
        OkHttpClient.Builder()
            .addNetworkInterceptor(Interceptor { chain ->

                val request: Request = chain.request()
                    .newBuilder()
                    .build()
                chain.proceed(request)
            }) //here we adding Interceptor for full level logging
            .addNetworkInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
            .build()

    private fun getRetrofit(): Retrofit {

        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(httpClient)
            .build()
    }

    val apiService: ApiService = getRetrofit().create(ApiService::class.java)

    //    private fun getToken(): String {
//        return Prefs.getString(PrefKeys.USER_ACCESS_TOKEN)
//    }
}