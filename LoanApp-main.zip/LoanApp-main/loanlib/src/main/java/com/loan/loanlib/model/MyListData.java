package com.loan.loanlib.model;

public class MyListData {
    public String title;
    public String subtitle;

    public MyListData(String description, String subtitle) {
        this.title = description;
        this.subtitle = subtitle;
    }

    public String getDescription() {
        return title;
    }

    public void setDescription(String description) {
        this.title = description;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
}