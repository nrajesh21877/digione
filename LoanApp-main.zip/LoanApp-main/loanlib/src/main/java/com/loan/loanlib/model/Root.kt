package com.loan.loanlib.model

class Root {
    var coord: Coord? = null
}