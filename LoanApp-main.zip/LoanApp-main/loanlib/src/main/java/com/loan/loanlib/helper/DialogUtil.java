package com.loan.loanlib.helper;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.loan.loanlib.R;


public class DialogUtil {

    static CustomProgressDialog m_cProgressBar;
    static Dialog currentDialog;
    private static DialogFragment dialogFragment;

    /**
     * Function to show a 'Please wait' ProgressDialog
     *
     * @param pContext Activity Instance of the activity which called this function
     */
    public static void displayProgress(Activity pContext) {
        displayProgress(pContext, "Please wait..");
    }

    public static void displayProgress(Activity pContext, String message) {

        if (null == m_cProgressBar) {
            if (pContext == null) return;
            if (pContext.isFinishing())
                return;
            m_cProgressBar = new CustomProgressDialog(pContext);
            m_cProgressBar.setCancelable(false);
            m_cProgressBar.show();
        }
    }

    /**
     * Function to dismiss the ProgressDialog
     */
    public static void stopProgressDisplay() {
        if (null != m_cProgressBar) {
            try {
                // IsShowoingOneDialog = false;
                m_cProgressBar.dismiss();
            } catch (Exception e) {

            }
        }
        m_cProgressBar = null;
    }

    public static boolean isInProgress() {
        if (null != m_cProgressBar) {
            return m_cProgressBar.isShowing();
        } else return false;
    }

    public static void showSnackBar(View view, int stringId) {
        DialogUtil.stopProgressDisplay();
        if (view == null) return;
        Snackbar snackbar = Snackbar
                .make(view, stringId, Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        int snackbarTextId = R.id.snackbar_text;
        TextView textView = snackbarView.findViewById(snackbarTextId);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public static void showSnackBar(View view, String string) {
        DialogUtil.stopProgressDisplay();
        if (view == null) return;
        Snackbar snackbar = Snackbar
                .make(view, string, Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        int snackbarTextId = R.id.snackbar_text;
        TextView textView = (TextView) snackbarView.findViewById(snackbarTextId);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public static void showToast(Context ctx, String message) {
        if (message == null || ctx == null) return;
        Toast toast = Toast.makeText(ctx, message, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }

    /**
     * Function to show a Dialog with two custom text buttons.
     *
     * @param pContext    Activity Instance of the activity which called this function
     * @param title       String containing the title of the Dialog box
     * @param msg         String containing the message to be displayed on Dialog Box
     * @param button1Text String containing the text of the button 1
     * @param listner1    OnClickListener for button 1
     * @param button2Text String containing the text of the button 2
     * @param listner2    OnClickListener for button 2
     */
    public static void displayMesage(Activity pContext, String title,
                                     String msg, String button1Text,
                                     DialogInterface.OnClickListener listner1, String button2Text, DialogInterface.OnClickListener listner2) {

        if (pContext == null) {
            return;
        }
        if (pContext.isFinishing())
            return;
        if (currentDialog != null) {
            currentDialog.setCancelable(false);
            //get the Context object that was used to great the dialog
            Context context = ((ContextWrapper) currentDialog.getContext()).getBaseContext();
            //if the Context used here was an activity AND it hasn't been finished or destroyed
            //then dismiss it
            if (context instanceof Activity) {
                if (!((Activity) context).isFinishing())
                    if (currentDialog.isShowing())
                        currentDialog.dismiss();
            } else //if the Context used wasnt an Activity, then dismiss it too
                currentDialog.dismiss();
        }

        stopProgressDisplay();
        AlertDialog.Builder alert = new AlertDialog.Builder(pContext);
        if (!TextUtils.isEmpty(title))
            alert.setTitle(title);
        alert.setMessage(msg);
        alert.setPositiveButton(button2Text, listner2);
        alert.setNegativeButton(button1Text, listner1);

        currentDialog = alert.create();
        currentDialog.show();
    }

    /**
     * Function to Dismiss the AlertDialog
     */
    public static synchronized void dismissDialog() {
        // TODO Auto-generated method stub
        if (dialogFragment != null && dialogFragment.isAdded()) {
            dialogFragment.dismissAllowingStateLoss();
            dialogFragment = null;
        }
        dialogFragment = null;
    }

}
