package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class Income(
    @SerializedName("IncomeTypeCode")
    val incomeTypeCode: String,
    @SerializedName("IncomeTypeId")
    val incomeTypeId: Int,
    @SerializedName("MasterType")
    val masterType: String
)