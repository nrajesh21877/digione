package com.loan.loanlib.adapter

import androidx.recyclerview.widget.RecyclerView
import android.view.ViewGroup
import android.view.LayoutInflater
import android.view.View
import com.loan.loanlib.R
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.loan.loanlib.model.LeadSummary

class LeadAdapter
    (private val leads: ArrayList<LeadSummary>, var listener: ItemClickListener) :
    RecyclerView.Adapter<LeadAdapter.ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val listItem =
            layoutInflater.inflate(R.layout.list_item_row, parent, false)
        return ViewHolder(listItem)
    }

    interface ItemClickListener {
        fun onSelected(lead: LeadSummary)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val lead = leads[position]
        holder.name.text = leads[position].leadName
        holder.slId.text = leads[position].leadSqId.toString()
        holder.mobile.text = leads[position].mobilenumber
        holder.item.setOnClickListener {
            listener.onSelected(lead)
        }
    }

    override fun getItemCount(): Int {
        return leads.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var name: TextView
        var slId: TextView
        var mobile: TextView
        var item: CardView

        init {
            name = itemView.findViewById<View>(R.id.name) as TextView
            slId = itemView.findViewById<View>(R.id.slid) as TextView
            mobile = itemView.findViewById<View>(R.id.mobile) as TextView
            item = itemView.findViewById<View>(R.id.item_view) as CardView
        }
    }
}