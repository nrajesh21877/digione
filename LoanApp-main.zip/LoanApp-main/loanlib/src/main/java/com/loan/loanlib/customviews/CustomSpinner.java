package com.loan.loanlib.customviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatSpinner;

import com.google.android.material.textfield.TextInputLayout;
import com.loan.loanlib.R;
import com.loan.loanlib.adapter.CustomAdapter;

import java.util.List;

public class CustomSpinner<T> extends LinearLayout {

    TextView mTitle;
    AppCompatSpinner mSpinner;
    CustomAdapter<T> mAdapter;

    public CustomSpinner(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFocusable(false);

        TypedArray a = context.obtainStyledAttributes(attrs,
                R.styleable.CustomView, 0, 0);

        String hint = a.getString(R.styleable.CustomView_hint);
        boolean underline = a.getBoolean(R.styleable.CustomView_underline, true);

        LayoutInflater li = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        LinearLayout layout = (LinearLayout) li.inflate(R.layout.widget_spinner, this, true);

        mTitle = layout.findViewById(R.id.title);
        if (TextUtils.isEmpty(hint)) {
            mTitle.setVisibility(GONE);
        } else {
            mTitle.setHint(hint);
            mTitle.setVisibility(VISIBLE);
        }

        mSpinner = layout.findViewById(R.id.spinner);
        if (underline) {
            mSpinner = layout.findViewById(R.id.spinnerUnlined);
        }
        mSpinner.setVisibility(VISIBLE);
    }

    public void initialize(List<T> values, onBindListener<T> listener) {
        mAdapter = new CustomAdapter<>(getContext(),
                values, listener::onBind);
        mSpinner.setAdapter(mAdapter);
    }

    public void initialize(List<T> values, T defaultValue, onBindListener<T> listener) {
        mAdapter = new CustomAdapter<>(getContext(),
                values, listener::onBind);
        mSpinner.setAdapter(mAdapter);

        setValue(listener.onBind(defaultValue), listener);
    }

    public void setValue(String value, onBindListener<T> listener) {

        CustomAdapter<T> adapter = (CustomAdapter<T>) mSpinner.getAdapter();

        for (int position = 0; position < adapter.getCount(); position++) {
            if (listener.onBind(adapter.getItem(position)).equals(value)) {
                getSpinner().setSelection(position);
                return;
            }
        }
    }

    public void registerOnChangeListener(onItemSelectedListener<T> listener) {
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                listener.onSelected(mAdapter.getItem(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public T getValue(int position) {
        return mAdapter.getItem(position);
    }

    public T getValue() {
        return mAdapter.getItem(getSpinner().getSelectedItemPosition());
    }

    public AppCompatSpinner getSpinner() {
        return mSpinner;
    }

    public interface onBindListener<T> {
        String onBind(T t);
    }

    public interface onItemSelectedListener<T> {
        void onSelected(T t);
    }
}