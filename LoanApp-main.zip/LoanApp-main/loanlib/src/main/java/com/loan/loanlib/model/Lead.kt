package com.loan.loanlib.model


import com.google.gson.annotations.SerializedName
import androidx.annotation.Keep

@Keep
data class Lead(
    @SerializedName("AnnualIncome")
    val annualIncome: Int,
    @SerializedName("AnnualTurnover")
    val annualTurnover: Int,
    @SerializedName("BusinessAddress")
    val businessAddress: String,
    @SerializedName("BusinessAddressPIN")
    val businessAddressPIN: String,
    @SerializedName("BusinessLatitude")
    val businessLatitude: String,
    @SerializedName("BusinessLongitude")
    val businessLongitude: String,
    @SerializedName("BusinessOwnerShipType")
    val businessOwnerShipType: Int,
    @SerializedName("CorrespondenseAddress")
    val correspondenseAddress: String,
    @SerializedName("CreatedBy")
    val createdBy: String,
    @SerializedName("CreatedById")
    val createdById: String,
    @SerializedName("CreatedByPartnerId")
    val createdByPartnerId: String,
    @SerializedName("CreatedDate")
    val createdDate: String,
    @SerializedName("DOB")
    val dOB: String,
    @SerializedName("EducationCode")
    val educationCode: Int,
    @SerializedName("Email")
    val email: String,
    @SerializedName("GST_CIN")
    val gSTCIN: String,
    @SerializedName("Gender")
    val gender: String,
    @SerializedName("IncomeType")
    val incomeType: Int,
    @SerializedName("Latitude")
    val latitude: String,
    @SerializedName("LeadName")
    val leadName: String,
    @SerializedName("LeadSqId")
    val leadSqId: Int,
    @SerializedName("LoanAmountRequired")
    val loanAmountRequired: Int,
    @SerializedName("LoanPurpose")
    val loanPurpose: Int,
    @SerializedName("Longitude")
    val longitude: String,
    @SerializedName("MaritalStatus")
    val maritalStatus: Int,
    @SerializedName("Mobilenumber")
    val mobilenumber: String,
    @SerializedName("NoOfYrInBusiness")
    val noOfYrInBusiness: Int,
    @SerializedName("OccupationType")
    val occupationType: Int,
    @SerializedName("PANNO")
    val pANNO: String,
    @SerializedName("PermanentAddress")
    val permanentAddress: String,
    @SerializedName("RepaymentTenure")
    val repaymentTenure: Int,
    @SerializedName("ResidenceAddress")
    val residenceAddress: String,
    @SerializedName("ServiceName")
    val serviceName: String,
    @SerializedName("SubLoanPurpose")
    val subLoanPurpose: Int,
    @SerializedName("UniqueId")
    val uniqueId: String,
    @SerializedName("WhatsAppNo")
    val whatsAppNo: String
)