package com.loan.loanlib.ui.main;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Build;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.DialogFragment;


@SuppressLint("ValidFragment")
public class DatePickerEdit extends DialogFragment implements
        DatePickerDialog.OnDateSetListener {

    EditText editText;

    public DatePickerEdit(EditText editText) {
        this.editText = editText;
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceSateate) {

        final Calendar c = Calendar.getInstance();
        int yearSelected = c.get(Calendar.YEAR);
        int monthOfYear = c.get(Calendar.MONTH);
        int dayOfMonth = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), this, yearSelected, monthOfYear, dayOfMonth);
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        return datePickerDialog;
    }

    public void onDateSet(DatePicker view, int yearSelected, int monthOfYear, int dayOfMonth) {
        monthOfYear = monthOfYear + 1;
        String month = Integer.toString(monthOfYear);
        String day = Integer.toString(dayOfMonth);
        if (monthOfYear < 10) {
            month = "" + month;
        }
        if (dayOfMonth < 10) {
            day = "" + day;
        }
        // Do something with the date chosen
        editText.setText(month + "/" + day + "/" + yearSelected);
    }
}
